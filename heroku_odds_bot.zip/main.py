
import requests
import time
from datetime import datetime, timedelta
import pytz
import telegram

# User credentials and keys
ODDS_API_KEY = "7b5d540e73c8790a95b84d3713e1a572"
TELEGRAM_BOT_TOKEN = "7607490683:AAH5LZ3hHnTimx35du-UQanEQBXpt6otjcI"
TELEGRAM_CHAT_ID = "964091254"

# Initialize bot
bot = telegram.Bot(token=TELEGRAM_BOT_TOKEN)

# OddsAPI settings
SPORT = "baseball_mlb"
REGIONS = "us"
MARKETS = "h2h,spreads,totals"
ODDS_FORMAT = "american"
DATE_FORMAT = "iso"
API_URL = f"https://api.the-odds-api.com/v4/sports/{{sport}}/odds"

# Time zone for filtering
now = datetime.now(pytz.utc)
end_of_tomorrow = now + timedelta(days=1)
end_of_tomorrow = end_of_tomorrow.replace(hour=23, minute=59, second=59)

def fetch_odds():
    url = f"{API_URL.format(sport=SPORT)}?apiKey={ODDS_API_KEY}&regions={REGIONS}&markets={MARKETS}&oddsFormat={ODDS_FORMAT}&dateFormat={DATE_FORMAT}"
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        print("Error fetching data:", e)
        return []

def filter_value_bets(games):
    bets = []
    for game in games:
        try:
            start_time = datetime.fromisoformat(game['commence_time'].replace("Z", "+00:00"))
            if start_time > end_of_tomorrow:
                continue

            for bookmaker in game.get("bookmakers", []):
                for market in bookmaker.get("markets", []):
                    for outcome in market.get("outcomes", []):
                        odds = outcome.get("price", 0)
                        if 130 <= odds <= 170:
                            bets.append({
                                "teams": game["teams"],
                                "home_team": game["home_team"],
                                "start_time": start_time.strftime("%Y-%m-%d %H:%M UTC"),
                                "market": market["key"],
                                "label": outcome["name"],
                                "odds": odds,
                                "bookmaker": bookmaker["title"]
                            })
        except Exception as e:
            print("Error processing game:", e)
    return bets

def send_bets_to_telegram(bets):
    for bet in bets:
        emoji = "🟢" if bet["odds"] >= 140 else "🟡"
        message = (
            f"{emoji} *{bet['label']}* ({bet['market'].upper()})
"
            f"🏟 {bet['teams'][0]} vs {bet['teams'][1]}
"
            f"📅 {bet['start_time']}
"
            f"💰 Odds: {bet['odds']} via {bet['bookmaker']}
"
            f"⚡ Bet Type: {bet['market']}
"
        )
        bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message, parse_mode=telegram.ParseMode.MARKDOWN)

if __name__ == "__main__":
    games = fetch_odds()
    filtered_bets = filter_value_bets(games)
    if filtered_bets:
        send_bets_to_telegram(filtered_bets)
    else:
        print("No value bets found.")
